import os
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from flask import Flask, render_template, request, jsonify

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")

MODEL_PATH = os.path.join(MODEL_DIR, "fraud_ann.keras")
PREPROCESSOR_PATH = os.path.join(MODEL_DIR, "preprocessor.joblib")
METRICS_PATH = os.path.join(MODEL_DIR, "metrics.joblib")

app = Flask(__name__)

model = None
preprocessor = None
metrics = {}


def load_artifacts():
    global model, preprocessor, metrics
    if not os.path.exists(MODEL_PATH) or not os.path.exists(PREPROCESSOR_PATH):
        return False
    model = tf.keras.models.load_model(MODEL_PATH)
    preprocessor = joblib.load(PREPROCESSOR_PATH)
    if os.path.exists(METRICS_PATH):
        metrics = joblib.load(METRICS_PATH)
    return True


def make_input(form):
    return pd.DataFrame([{
        "Transaction Amount (₹)": float(form["amount"]),
        "Transaction Type": form["transaction_type"],
        "Time": int(form["time"]),
        "Previous Transactions": int(form["previous_transactions"]),
        "Location": form["location"],
        "Frequency": float(form["frequency"]),
        "Risk Score": float(form["risk_score"]),
        "Device Type": form["device_type"],
        "Merchant Category": form["merchant_category"],
        "Payment Method": form["payment_method"],
        "IP Risk Score": float(form["ip_risk_score"]),
        "International Transaction": form["international"],
        "Failed Attempts": int(form["failed_attempts"]),
        "Account Age (days)": int(form["account_age"]),
        "Average Transaction (₹)": float(form["average_transaction"]),
        "Distance From Usual Location (km)": float(form["distance"]),
        "Weekend": form["weekend"],
    }])


@app.route("/")
def home():
    return render_template("home.html", active="home", metrics=metrics, ready=model is not None)


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", active="dashboard", metrics=metrics, ready=model is not None)


@app.route("/detection")
def detection():
    return render_template("detection.html", active="detection", metrics=metrics, ready=model is not None)


@app.route("/about")
def about():
    return render_template("about.html", active="about", metrics=metrics, ready=model is not None)


@app.route("/predict", methods=["POST"])
def predict():
    if model is None or preprocessor is None:
        return jsonify({
            "success": False,
            "message": "Model is not trained yet. Run: python train_model.py"
        }), 503

    try:
        df = make_input(request.form)
        transformed = preprocessor.transform(df).astype("float32")
        probability = float(model.predict(transformed, verbose=0)[0][0])
        fraud_probability = probability * 100.0
        is_fraud = probability >= 0.50

        if fraud_probability < 25:
            risk_level = "Low"
            message = "The transaction looks relatively normal based on the entered details."
        elif fraud_probability < 60:
            risk_level = "Medium"
            message = "Some transaction characteristics deserve additional verification."
        elif fraud_probability < 80:
            risk_level = "High"
            message = "Several characteristics are associated with elevated fraud risk."
        else:
            risk_level = "Very High"
            message = "The model detected a high-risk pattern. Verify the transaction carefully."

        return jsonify({
            "success": True,
            "prediction": "Fraud" if is_fraud else "Genuine",
            "fraud_probability": round(fraud_probability, 2),
            "risk_level": risk_level,
            "message": message
        })
    except Exception as exc:
        return jsonify({"success": False, "message": f"Prediction error: {str(exc)}"}), 400


@app.route("/health")
def health():
    return jsonify({"status": "ok", "model_loaded": model is not None})


if __name__ == "__main__":
    if not load_artifacts():
        print("Model files not found. Run: python train_model.py")
    else:
        print("ANN model loaded successfully.")
    app.run(debug=True, host="127.0.0.1", port=5000)
