import os
import random
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, roc_auc_score
from sklearn.utils.class_weight import compute_class_weight

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

DATA_PATH = os.path.join(DATA_DIR, "fraud_transactions.csv")
MODEL_PATH = os.path.join(MODEL_DIR, "fraud_ann.keras")
PREPROCESSOR_PATH = os.path.join(MODEL_DIR, "preprocessor.joblib")
FEATURE_INFO_PATH = os.path.join(MODEL_DIR, "feature_info.joblib")
METRICS_PATH = os.path.join(MODEL_DIR, "metrics.joblib")


def make_dataset(n=15000):
    """Create a synthetic but realistic-looking demo dataset."""
    rng = np.random.default_rng(SEED)

    transaction_type = rng.choice(
        ["Online Purchase", "POS Purchase", "ATM Withdrawal", "Bank Transfer", "Bill Payment"],
        n, p=[0.34, 0.30, 0.10, 0.14, 0.12]
    )
    location = rng.choice(
        ["Hyderabad", "Bengaluru", "Chennai", "Mumbai", "Delhi", "Pune", "Kolkata", "Other"],
        n
    )
    device_type = rng.choice(["Mobile", "Laptop", "Desktop", "Tablet"], n, p=[0.55, 0.22, 0.15, 0.08])
    merchant_category = rng.choice(
        ["Grocery", "Electronics", "Travel", "Food", "Fuel", "Clothing", "Entertainment", "Healthcare", "Online Services"],
        n
    )
    payment_method = rng.choice(
        ["Credit Card", "Debit Card", "UPI", "Net Banking", "Wallet"],
        n, p=[0.34, 0.22, 0.25, 0.12, 0.07]
    )

    amount = np.clip(rng.lognormal(mean=7.0, sigma=0.9, size=n), 50, 200000)
    previous_transactions = rng.poisson(18, n) + 1
    frequency = np.clip(rng.normal(5.5, 3.2, n), 0.2, 30)
    risk_score = np.clip(rng.beta(2.0, 7.0, n) * 100, 0, 100)
    ip_risk = np.clip(rng.beta(2.0, 6.0, n) * 100, 0, 100)
    failed_attempts = np.clip(rng.poisson(0.45, n), 0, 6)
    account_age = np.clip(rng.gamma(4.0, 180, n), 5, 3000)
    avg_transaction = np.clip(rng.lognormal(mean=6.6, sigma=0.55, size=n), 50, 50000)
    distance = np.clip(rng.gamma(1.7, 18, n), 0, 800)
    weekend = rng.choice(["Yes", "No"], n, p=[0.29, 0.71])
    international = rng.choice(["Yes", "No"], n, p=[0.08, 0.92])

    # Hour represented as 0-23. Fraud is somewhat more common in unusual hours.
    hour = rng.integers(0, 24, n)

    amount_ratio = amount / np.maximum(avg_transaction, 1)

    # Build a synthetic fraud-risk score.
    score = (
        -5.2
        + 0.035 * risk_score
        + 0.040 * ip_risk
        + 0.42 * failed_attempts
        + 0.55 * np.clip(amount_ratio - 1, 0, 8)
        + 0.0015 * distance
        + 0.00012 * amount
        + 0.75 * (international == "Yes")
        + 0.40 * (hour <= 5)
        + 0.22 * (weekend == "Yes")
        + 0.35 * (device_type == "Desktop")
        + 0.30 * (payment_method == "Wallet")
        + 0.25 * (transaction_type == "ATM Withdrawal")
        + rng.normal(0, 0.55, n)
    )

    probability = 1 / (1 + np.exp(-score))
    fraud = rng.binomial(1, probability)

    # Keep a useful fraud ratio for a classroom/demo dataset.
    # If too low/high, the model still trains, but this keeps examples balanced enough.
    current_rate = fraud.mean()
    if current_rate < 0.12:
        extra = rng.random(n) < 0.10
        fraud = np.where(extra, 1, fraud)
    elif current_rate > 0.35:
        keep = rng.random(n) > 0.12
        fraud = np.where(keep, fraud, 0)

    df = pd.DataFrame({
        "Transaction Amount (₹)": np.round(amount, 2),
        "Transaction Type": transaction_type,
        "Time": hour,
        "Previous Transactions": previous_transactions,
        "Location": location,
        "Frequency": np.round(frequency, 2),
        "Risk Score": np.round(risk_score, 2),
        "Device Type": device_type,
        "Merchant Category": merchant_category,
        "Payment Method": payment_method,
        "IP Risk Score": np.round(ip_risk, 2),
        "International Transaction": international,
        "Failed Attempts": failed_attempts,
        "Account Age (days)": np.round(account_age, 0).astype(int),
        "Average Transaction (₹)": np.round(avg_transaction, 2),
        "Distance From Usual Location (km)": np.round(distance, 2),
        "Weekend": weekend,
        "Fraud": fraud
    })

    return df


def build_and_train():
    print("Creating synthetic transaction dataset...")
    df = make_dataset()
    df.to_csv(DATA_PATH, index=False)

    target = "Fraud"
    categorical_cols = [
        "Transaction Type",
        "Location",
        "Device Type",
        "Merchant Category",
        "Payment Method",
        "International Transaction",
        "Weekend"
    ]
    numerical_cols = [
        "Transaction Amount (₹)",
        "Time",
        "Previous Transactions",
        "Frequency",
        "Risk Score",
        "IP Risk Score",
        "Failed Attempts",
        "Account Age (days)",
        "Average Transaction (₹)",
        "Distance From Usual Location (km)"
    ]

    X = df[categorical_cols + numerical_cols]
    y = df[target].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=SEED, stratify=y
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numerical_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical_cols)
        ]
    )

    X_train_p = preprocessor.fit_transform(X_train).astype("float32")
    X_test_p = preprocessor.transform(X_test).astype("float32")

    # Deep-learning ANN.
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(X_train_p.shape[1],)),
        tf.keras.layers.Dense(128, activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.30),

        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.25),

        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dropout(0.15),

        tf.keras.layers.Dense(1, activation="sigmoid")
    ])

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss="binary_crossentropy",
        metrics=[
            "accuracy",
            tf.keras.metrics.Precision(name="precision"),
            tf.keras.metrics.Recall(name="recall"),
            tf.keras.metrics.AUC(name="auc")
        ]
    )

    classes = np.unique(y_train)
    weights = compute_class_weight(class_weight="balanced", classes=classes, y=y_train)
    class_weights = dict(zip(classes, weights))

    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_auc", mode="max", patience=5, restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=2, min_lr=1e-6
        )
    ]

    print("\nTraining ANN...")
    history = model.fit(
        X_train_p,
        y_train,
        validation_split=0.20,
        epochs=30,
        batch_size=64,
        class_weight=class_weights,
        callbacks=callbacks,
        verbose=1
    )

    print("\nEvaluating model...")
    probabilities = model.predict(X_test_p, verbose=0).ravel()
    predictions = (probabilities >= 0.5).astype(int)

    accuracy = accuracy_score(y_test, predictions)
    auc = roc_auc_score(y_test, probabilities)
    cm = confusion_matrix(y_test, predictions)

    print("\n===== MODEL RESULTS =====")
    print(f"Accuracy : {accuracy:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")
    print("\nConfusion Matrix:")
    print(cm)
    print("\nClassification Report:")
    print(classification_report(y_test, predictions, digits=4))

    model.save(MODEL_PATH)
    joblib.dump(preprocessor, PREPROCESSOR_PATH)
    joblib.dump(
        {
            "categorical_cols": categorical_cols,
            "numerical_cols": numerical_cols,
            "all_input_cols": categorical_cols + numerical_cols,
        },
        FEATURE_INFO_PATH
    )
    joblib.dump(
        {
            "accuracy": float(accuracy),
            "auc": float(auc),
            "fraud_rate": float(y.mean()),
            "train_rows": int(len(X_train)),
            "test_rows": int(len(X_test)),
        },
        METRICS_PATH
    )

    print("\nSaved files:")
    print(MODEL_PATH)
    print(PREPROCESSOR_PATH)
    print(FEATURE_INFO_PATH)
    print(METRICS_PATH)
    print(DATA_PATH)
    print("\nTraining completed successfully.")


if __name__ == "__main__":
    build_and_train()
