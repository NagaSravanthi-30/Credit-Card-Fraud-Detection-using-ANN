The transaction dataset is generated automatically by train_model.py.
Run:

python train_model.py

It creates data/fraud_transactions.csv with 15,000 synthetic transaction records.
