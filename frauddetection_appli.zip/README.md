# FraudShield AI - 4 Page ANN Application

Pages:
1. Home - project introduction and quick actions
2. Dashboard - model/system overview
3. Detection - 17-field fraud prediction form
4. About Model - ANN architecture and preprocessing

## Run

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
python app.py
```

Open:
http://127.0.0.1:5000

The training data is synthetic and for educational demonstration only.
